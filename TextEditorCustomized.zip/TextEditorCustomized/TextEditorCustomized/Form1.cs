
using System;
using System.Windows.Forms;
using System.IO; //used to modify files(read, write)
using System.Drawing.Drawing2D;


namespace TextEditorCustomized
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Remove all text from Text-box
            richTextBox1.Text = " ";
        }

        private void OpenDlg() {
            //Open a file
            OpenFileDialog ofd = new OpenFileDialog();

            //Open file dialog files extension filter
            ofd.Filter = "Text File|*.txt|Any File|*.*";
            
            //if after showing dialog, clicked ok
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                //open file
                StreamReader sr = new StreamReader(ofd.FileName);

                //Place file text to text box
                richTextBox1.Text = sr.ReadToEnd();

                //close file
                sr.Close();

                //text of this window = path of currently opened file
                this.Text = ofd.FileName;
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {          
            OpenDlg();
        }


        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try {
            //save file
            StreamWriter sw = new StreamWriter(this.Text);
            sw.Write(richTextBox1.Text);
            sw.Close();
            }
            catch {
                MessageBox.Show("Failed saving");
                OpenDlg();
            }

        }

        //save file method
        private void SaveDlg()
        {
            //New save file dialog
            SaveFileDialog sf = new SaveFileDialog();
            //filter
            sf.Filter = "Text File|*.txt|Any File|*.*";
            //if after showing dialog, user clicked ok
            if (sf.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sr = new StreamWriter(sf.FileName);
                sr.Write(richTextBox1.Text);
                sr.Close();
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveDlg();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close application
            Application.Exit();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //new color choosing dialog
            ColorDialog cd = new ColorDialog();
            //if after showing dialog, user clocked ok
            if (cd.ShowDialog() == DialogResult.OK)
            { 
                //set background color to text box
                richTextBox1.BackColor=cd.Color;
            
            }
        }

        private void textColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //new color choosing dialog
            ColorDialog cd = new ColorDialog();
            //if after showing dialog, user clocked ok
            if (cd.ShowDialog() == DialogResult.OK)
            {
                //set text color to text box
                richTextBox1.ForeColor = cd.Color;
               
            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //new Font choosing dialog
            FontDialog cd = new FontDialog();
            //if after showing dialog, user clocked ok
            if (cd.ShowDialog() == DialogResult.OK)
            {
                //set Font color to text box
                richTextBox1.Font = cd.Font;

            }
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Redo();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
